package com.cs421.rccar.Util;

public enum BluetoothState
{
    STATE_NONE,
    STATE_LISTEN,
    STATE_CONNECTING,
    STATE_CONNECTED
}
